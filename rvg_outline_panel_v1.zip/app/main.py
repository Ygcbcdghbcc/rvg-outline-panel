import os
import io
import qrcode
from fastapi import FastAPI, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import select
from passlib.hash import bcrypt

from .db import Base, engine, SessionLocal
from .models import OutlineServer, AccessKey
from .outline import OutlineClient

Base.metadata.create_all(engine)

app = FastAPI(title="RVG Outline Panel V1")
app.add_middleware(SessionMiddleware, secret_key=os.getenv("SESSION_SECRET", "dev-change-me"))
templates = Jinja2Templates(directory="app/templates")

ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "change-me")
VERIFY_TLS = os.getenv("OUTLINE_VERIFY_TLS", "false").lower() == "true"

def db():
    s = SessionLocal()
    try:
        yield s
    finally:
        s.close()

def auth(request: Request):
    if not request.session.get("user"):
        return False
    return True

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "error": None})

@app.post("/login")
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
        request.session["user"] = username
        return RedirectResponse("/", status_code=303)
    return templates.TemplateResponse("login.html", {"request": request, "error": "نام کاربری یا رمز عبور اشتباه است."})

@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=303)

@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, session: Session = Depends(db)):
    if not auth(request): return RedirectResponse("/login", status_code=303)
    servers = session.scalars(select(OutlineServer).order_by(OutlineServer.id.desc())).all()
    keys = session.scalars(select(AccessKey).order_by(AccessKey.id.desc())).all()
    return templates.TemplateResponse("dashboard.html", {"request": request, "servers": servers, "keys": keys})

@app.post("/servers")
def add_server(request: Request, name: str = Form(...), api_url: str = Form(...), session: Session = Depends(db)):
    if not auth(request): return RedirectResponse("/login", status_code=303)
    server = OutlineServer(name=name.strip(), api_url=api_url.strip())
    session.add(server); session.commit()
    return RedirectResponse("/", status_code=303)

@app.post("/servers/{server_id}/keys")
async def create_key(request: Request, server_id: int, name: str = Form(...), limit_gb: int = Form(0), session: Session = Depends(db)):
    if not auth(request): return RedirectResponse("/login", status_code=303)
    server = session.get(OutlineServer, server_id)
    if not server: return RedirectResponse("/", status_code=303)
    result = await OutlineClient(server.api_url, VERIFY_TLS).create_key(name.strip(), limit_gb or None)
    key = AccessKey(server_id=server.id, remote_id=result["id"], name=result.get("name", name), access_url=result.get("accessUrl", ""), limit_gb=limit_gb or None)
    session.add(key); session.commit()
    return RedirectResponse("/", status_code=303)

@app.post("/keys/{key_id}/delete")
async def delete_key(request: Request, key_id: int, session: Session = Depends(db)):
    if not auth(request): return RedirectResponse("/login", status_code=303)
    key = session.get(AccessKey, key_id)
    if key:
        server = session.get(OutlineServer, key.server_id)
        try:
            await OutlineClient(server.api_url, VERIFY_TLS).delete_key(key.remote_id)
        finally:
            session.delete(key); session.commit()
    return RedirectResponse("/", status_code=303)

@app.get("/keys/{key_id}/qr")
def qr(request: Request, key_id: int, session: Session = Depends(db)):
    if not auth(request): return RedirectResponse("/login", status_code=303)
    key = session.get(AccessKey, key_id)
    if not key or not key.access_url: return HTMLResponse("Not found", status_code=404)
    img = qrcode.make(key.access_url)
    buf = io.BytesIO(); img.save(buf, format="PNG"); buf.seek(0)
    return StreamingResponse(buf, media_type="image/png")

@app.post("/servers/{server_id}/sync")
async def sync_keys(request: Request, server_id: int, session: Session = Depends(db)):
    if not auth(request): return RedirectResponse("/login", status_code=303)
    server = session.get(OutlineServer, server_id)
    if server:
        remote = await OutlineClient(server.api_url, VERIFY_TLS).list_keys()
        known = {k.remote_id: k for k in session.scalars(select(AccessKey).where(AccessKey.server_id == server.id)).all()}
        for r in remote:
            if r["id"] not in known:
                session.add(AccessKey(server_id=server.id, remote_id=r["id"], name=r.get("name",""), access_url=r.get("accessUrl","")))
        session.commit()
    return RedirectResponse("/", status_code=303)
