import httpx

class OutlineClient:
    def __init__(self, api_url: str, verify: bool = False):
        self.base = api_url.rstrip("/")
        self.verify = verify

    async def list_keys(self):
        async with httpx.AsyncClient(verify=self.verify, timeout=15) as c:
            r = await c.get(f"{self.base}/access-keys")
            r.raise_for_status()
            return r.json().get("accessKeys", [])

    async def create_key(self, name: str, limit_gb: int | None = None):
        payload = {"name": name}
        if limit_gb and limit_gb > 0:
            payload["limit"] = {"bytes": int(limit_gb) * 1024**3}
        async with httpx.AsyncClient(verify=self.verify, timeout=15) as c:
            r = await c.post(f"{self.base}/access-keys", json=payload)
            r.raise_for_status()
            return r.json()

    async def delete_key(self, remote_id: str):
        async with httpx.AsyncClient(verify=self.verify, timeout=15) as c:
            r = await c.delete(f"{self.base}/access-keys/{remote_id}")
            r.raise_for_status()

    async def set_limit(self, remote_id: str, limit_gb: int):
        payload = {"limit": {"bytes": int(limit_gb) * 1024**3}}
        async with httpx.AsyncClient(verify=self.verify, timeout=15) as c:
            r = await c.put(f"{self.base}/access-keys/{remote_id}", json=payload)
            r.raise_for_status()
            return r.json()
